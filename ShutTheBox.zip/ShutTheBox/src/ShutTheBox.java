
public class ShutTheBox {

	public static void main(String[] args) {
		
	}
}
